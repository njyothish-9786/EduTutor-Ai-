
import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import ConceptExplainer from './components/ConceptExplainer';
import QuizGenerator from './components/QuizGenerator';
import EssayHelper from './components/EssayHelper';
import ApiKeyBanner from './components/shared/ApiKeyBanner';
import { Feature, Course } from './types';
import { COURSES } from './constants';

const App: React.FC = () => {
  const [selectedCourse, setSelectedCourse] = useState<Course>(COURSES[0]);
  const [selectedFeature, setSelectedFeature] = useState<Feature>('Explain');

  const renderFeatureComponent = () => {
    switch (selectedFeature) {
      case 'Explain':
        return <ConceptExplainer course={selectedCourse} />;
      case 'Quiz':
        return <QuizGenerator course={selectedCourse} />;
      case 'Essay':
        return <EssayHelper course={selectedCourse} />;
      default:
        return <ConceptExplainer course={selectedCourse} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans text-gray-800 dark:text-gray-200 bg-gray-50 dark:bg-gray-900">
      <Header />
      <div className="flex flex-1 flex-col md:flex-row">
        <Sidebar
          selectedCourse={selectedCourse}
          setSelectedCourse={setSelectedCourse}
          selectedFeature={selectedFeature}
          setSelectedFeature={setSelectedFeature}
        />
        <main className="flex-1 p-4 md:p-8 overflow-y-auto">
          {renderFeatureComponent()}
        </main>
      </div>
      <ApiKeyBanner />
    </div>
  );
};

export default App;