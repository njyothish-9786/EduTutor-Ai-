
import React from 'react';
import { Course } from './types';

export const COURSES: Course[] = [
  { id: 'history', name: 'World History', icon: <i className="fa-solid fa-landmark-dome w-5 text-center"></i> },
  { id: 'science', name: 'Biology', icon: <i className="fa-solid fa-dna w-5 text-center"></i> },
  { id: 'literature', name: 'Literature', icon: <i className="fa-solid fa-book-open w-5 text-center"></i> },
  { id: 'math', name: 'Algebra', icon: <i className="fa-solid fa-calculator w-5 text-center"></i> },
  { id: 'cs', name: 'Computer Science', icon: <i className="fa-solid fa-code w-5 text-center"></i> },
  { id: 'accounting', name: 'Accounting', icon: <i className="fa-solid fa-file-invoice-dollar w-5 text-center"></i> },
  { id: 'commerce', name: 'Business Studies', icon: <i className="fa-solid fa-briefcase w-5 text-center"></i> },
];
