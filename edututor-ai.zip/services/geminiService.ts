
import { GoogleGenAI } from "@google/genai";
import { QuizData } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This check is for development; the ApiKeyBanner will handle the UI notice.
  console.warn("API_KEY environment variable not set. App will not function correctly.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

const parseJsonFromMarkdown = <T,>(text: string): T | null => {
  let jsonStr = text.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }
  try {
    return JSON.parse(jsonStr) as T;
  } catch (e) {
    console.error("Failed to parse JSON response:", e);
    // Attempt to fix common JSON errors, like trailing commas
    try {
        const sanitizedJson = jsonStr.replace(/,\s*([}\]])/g, '$1');
        return JSON.parse(sanitizedJson) as T;
    } catch (e2) {
        console.error("Failed to parse sanitized JSON response:", e2);
        return null;
    }
  }
};


export const explainConcept = async (topic: string, courseName: string): Promise<string> => {
  try {
    const systemInstruction = `You are EduTutor AI, an expert tutor specializing in ${courseName}. Explain the following concept in a clear, concise, and engaging way for a high school student. Use markdown for formatting, like lists, bold text, and italics to improve readability.`;
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: topic,
      config: {
        systemInstruction,
        temperature: 0.7,
        topP: 0.95,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Error explaining concept:", error);
    return "An error occurred while trying to explain the concept. Please check your API key and try again.";
  }
};

export const generateQuiz = async (topic: string, courseName: string): Promise<QuizData | null> => {
   try {
    const systemInstruction = `You are EduTutor AI, an expert quiz creator for ${courseName}. Generate a 3-question multiple-choice quiz about the given topic. For each question, provide four options and identify the correct answer. Your response MUST be a valid JSON object following this exact structure: { "questions": [{ "question": "...", "options": ["...", "...", "...", "..."], "answer": "..." }] }`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17",
        contents: `Topic: ${topic}`,
        config: {
            systemInstruction,
            responseMimeType: "application/json",
            temperature: 0.5,
        },
    });

    const parsedData = parseJsonFromMarkdown<QuizData>(response.text);
    if (!parsedData || !Array.isArray(parsedData.questions) || parsedData.questions.length === 0) {
        console.error("Parsed data is not in the expected QuizData format:", parsedData);
        return null;
    }
    return parsedData;

   } catch (error) {
     console.error("Error generating quiz:", error);
     return null;
   }
};

export const helpWithEssay = async (topic: string, courseName: string): Promise<string> => {
  try {
    const systemInstruction = `You are EduTutor AI, an expert writing assistant for ${courseName}. Your task is to help a student get started on an essay. Based on the provided topic, generate a concise and compelling introductory paragraph. The paragraph should introduce the topic, state a clear thesis, and outline the main points that will be discussed.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: `Essay Topic: ${topic}`,
      config: {
        systemInstruction,
        temperature: 0.8,
        topP: 0.95,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Error with essay helper:", error);
    return "An error occurred while generating essay assistance. Please check your API key and try again.";
  }
};