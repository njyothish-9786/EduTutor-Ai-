
import React from 'react';
import { Course, Feature } from '../types';
import { COURSES } from '../constants';

interface SidebarProps {
  selectedCourse: Course;
  setSelectedCourse: (course: Course) => void;
  selectedFeature: Feature;
  setSelectedFeature: (feature: Feature) => void;
}

const FEATURES: { name: Feature; icon: React.ReactNode }[] = [
  { name: 'Explain', icon: <i className="fa-solid fa-book-sparkles w-5 text-center"></i> },
  { name: 'Quiz', icon: <i className="fa-solid fa-file-circle-question w-5 text-center"></i> },
  { name: 'Essay', icon: <i className="fa-solid fa-pen-nib w-5 text-center"></i> },
];

const Sidebar: React.FC<SidebarProps> = ({ selectedCourse, setSelectedCourse, selectedFeature, setSelectedFeature }) => {
  return (
    <aside className="w-full md:w-64 bg-white dark:bg-gray-800 p-6 flex-shrink-0 border-r border-gray-200 dark:border-gray-700">
      <nav className="space-y-8">
        <div>
          <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">Courses</h3>
          <div className="space-y-2">
            {COURSES.map((course) => (
              <button
                key={course.id}
                onClick={() => setSelectedCourse(course)}
                className={`w-full flex items-center space-x-3 p-2 rounded-lg text-left transition-all duration-200 ${
                  selectedCourse.id === course.id
                    ? 'bg-blue-500 text-white shadow-md'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                {course.icon}
                <span className="font-medium">{course.name}</span>
              </button>
            ))}
          </div>
        </div>
        <div>
          <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">Tools</h3>
          <div className="space-y-2">
            {FEATURES.map((feature) => (
              <button
                key={feature.name}
                onClick={() => setSelectedFeature(feature.name)}
                className={`w-full flex items-center space-x-3 p-2 rounded-lg text-left transition-all duration-200 ${
                  selectedFeature === feature.name
                    ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-300'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                {feature.icon}
                <span className="font-medium">
                  {feature.name === 'Explain' && 'Explain a Concept'}
                  {feature.name === 'Quiz' && 'Generate a Quiz'}
                  {feature.name === 'Essay' && 'Essay Helper'}
                </span>
              </button>
            ))}
          </div>
        </div>
      </nav>
    </aside>
  );
};

export default Sidebar;