
import React, { useState, useCallback } from 'react';
import { Course } from '../types';
import { explainConcept } from '../services/geminiService';
import Spinner from './shared/Spinner';
import Card from './shared/Card';

interface ConceptExplainerProps {
  course: Course;
}

const ConceptExplainer: React.FC<ConceptExplainerProps> = ({ course }) => {
  const [topic, setTopic] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [explanation, setExplanation] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!topic.trim()) {
      setError('Please enter a topic to explain.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setExplanation(null);
    try {
      const result = await explainConcept(topic, course.name);
      setExplanation(result);
    } catch (err) {
      setError('Failed to get explanation. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [topic, course.name]);

  return (
    <Card>
      <div className="p-6">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-1">Concept Explainer</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-4">
          Stuck on a topic in <span className="font-semibold text-blue-500">{course.name}</span>? Enter it below.
        </p>
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g., Photosynthesis, The Cold War, Polymorphism"
            className="flex-grow p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            disabled={isLoading}
          />
          <button
            onClick={handleGenerate}
            disabled={isLoading || !topic.trim()}
            className="px-6 py-3 bg-blue-500 text-white font-semibold rounded-lg shadow-md hover:bg-blue-600 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center"
          >
            {isLoading ? <Spinner /> : 'Explain'}
          </button>
        </div>
        {error && <p className="text-red-500 mt-4">{error}</p>}
      </div>
      {(isLoading || explanation) && (
        <div className="border-t border-gray-200 dark:border-gray-700 p-6">
          {isLoading && (
            <div className="flex justify-center items-center space-x-2 text-gray-600 dark:text-gray-400">
              <Spinner />
              <span>EduTutor AI is thinking...</span>
            </div>
          )}
          {explanation && (
            <div
              className="prose prose-blue dark:prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: explanation.replace(/\n/g, '<br />') }}
            />
          )}
        </div>
      )}
    </Card>
  );
};

export default ConceptExplainer;