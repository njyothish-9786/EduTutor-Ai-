
import React, { useState, useCallback } from 'react';
import { Course } from '../types';
import { helpWithEssay } from '../services/geminiService';
import Spinner from './shared/Spinner';
import Card from './shared/Card';

interface EssayHelperProps {
  course: Course;
}

const EssayHelper: React.FC<EssayHelperProps> = ({ course }) => {
  const [topic, setTopic] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [essayIntro, setEssayIntro] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!topic.trim()) {
      setError('Please enter an essay topic.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setEssayIntro(null);
    try {
      const result = await helpWithEssay(topic, course.name);
      setEssayIntro(result);
    } catch (err) {
      setError('Failed to get essay help. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, [topic, course.name]);

  return (
    <Card>
      <div className="p-6">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-1">Essay Helper</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-4">
          Get help starting your <span className="font-semibold text-blue-500">{course.name}</span> essay. Enter your topic for an introduction.
        </p>
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g., The impact of Shakespeare on modern English"
            className="flex-grow p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            disabled={isLoading}
          />
          <button
            onClick={handleGenerate}
            disabled={isLoading || !topic.trim()}
            className="px-6 py-3 bg-blue-500 text-white font-semibold rounded-lg shadow-md hover:bg-blue-600 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center"
          >
            {isLoading ? <Spinner /> : 'Get Help'}
          </button>
        </div>
        {error && <p className="text-red-500 mt-4">{error}</p>}
      </div>
      {(isLoading || essayIntro) && (
        <div className="border-t border-gray-200 dark:border-gray-700 p-6">
          {isLoading && (
            <div className="flex justify-center items-center space-x-2 text-gray-600 dark:text-gray-400">
              <Spinner />
              <span>EduTutor AI is drafting an introduction...</span>
            </div>
          )}
          {essayIntro && (
            <div>
              <h3 className="text-xl font-bold mb-4">Suggested Introduction:</h3>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">{essayIntro}</p>
            </div>
          )}
        </div>
      )}
    </Card>
  );
};

export default EssayHelper;