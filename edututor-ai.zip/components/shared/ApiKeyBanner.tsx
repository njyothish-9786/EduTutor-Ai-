
import React from 'react';

const ApiKeyBanner: React.FC = () => {
  // This component only renders if the API key is missing.
  if (process.env.API_KEY) {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-red-600 text-white p-3 text-center z-50">
      <i className="fa-solid fa-triangle-exclamation mr-2"></i>
      <strong>API Key Not Found.</strong> Please set the `process.env.API_KEY` environment variable for the application to function.
    </div>
  );
};

export default ApiKeyBanner;
