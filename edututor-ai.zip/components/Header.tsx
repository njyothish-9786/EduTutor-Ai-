
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white dark:bg-gray-800 shadow-md p-4 flex items-center border-b-2 border-blue-500">
      <div className="flex items-center space-x-3">
        <div className="bg-blue-500 p-2 rounded-lg">
          <i className="fa-solid fa-graduation-cap text-white text-2xl"></i>
        </div>
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white tracking-tight">
          EduTutor AI
        </h1>
      </div>
    </header>
  );
};

export default Header;
